# artificial_neural_network

## Download

```
pip install git+https://github.com/IanAguiar-ai/artificial_neural_network
```
