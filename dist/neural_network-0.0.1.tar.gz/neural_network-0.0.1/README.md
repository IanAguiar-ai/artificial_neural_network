# artificial_neural_network
Rede Neural Artificial do zero.
